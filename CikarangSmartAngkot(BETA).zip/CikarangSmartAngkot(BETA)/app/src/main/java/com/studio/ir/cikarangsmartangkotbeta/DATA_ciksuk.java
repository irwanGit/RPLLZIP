package com.studio.ir.cikarangsmartangkotbeta;

import android.app.Activity;
import android.os.Bundle;

public class DATA_ciksuk extends Activity{

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.data_ciksuk);


        }
    }
